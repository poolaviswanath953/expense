# Personal Expense Tracker (Flask + MySQL)
Contains budget alerts (per-category + overall monthly) and basic expense tracking.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Create MySQL database and tables using `models/db_setup.sql`.
3. Set environment variables (optional) or edit `config.py` for DB credentials.
4. Run the app:
   ```bash
   export FLASK_APP=app.py
   flask run
   ```
Visit http://127.0.0.1:5000/
